from .version import __version__  # noqa: used externally

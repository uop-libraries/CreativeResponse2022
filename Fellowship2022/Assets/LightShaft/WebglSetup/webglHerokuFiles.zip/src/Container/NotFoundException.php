<?php

namespace YoutubeDownloader\Container;

/**
 * No entry was found in the container.
 */
class NotFoundException extends ContainerException
{
}
